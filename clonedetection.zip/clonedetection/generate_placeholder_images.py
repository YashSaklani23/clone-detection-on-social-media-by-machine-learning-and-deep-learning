from PIL import Image
import numpy as np
import os

# Create images directory
images_dir = os.path.join('data', 'images')
os.makedirs(images_dir, exist_ok=True)

# Generate 100 placeholder images
for i in range(1, 101):
    img = Image.new('RGB', (64, 64), color=(np.random.randint(0, 255), np.random.randint(0, 255), np.random.randint(0, 255)))
    img_path = os.path.join(images_dir, f'user{i}.jpg')
    img.save(img_path)
    print(f"Saved placeholder image: {img_path}")
print(f"Placeholder images saved to '{images_dir}'.")
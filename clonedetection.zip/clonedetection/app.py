from flask import Flask, request, render_template
import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model
from transformers import BertTokenizer, TFBertModel
from tensorflow.keras.preprocessing.sequence import pad_sequences
from fuzzywuzzy import fuzz
import pickle
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import os

app = Flask(__name__)

# Load models and resources
try:
    nn_model = load_model('models/clone_detection_model.h5')
except FileNotFoundError:
    print("Error: Neural Network model file 'clone_detection_model.h5' not found.")
    exit(1)

try:
    with open('models/svm_model.pkl', 'rb') as f:
        svm_model = pickle.load(f)
except FileNotFoundError:
    print("Error: SVM model file 'svm_model.pkl' not found.")
    exit(1)

try:
    with open('models/rf_model.pkl', 'rb') as f:
        rf_model = pickle.load(f)
except FileNotFoundError:
    print("Error: Random Forest model file 'rf_model.pkl' not found.")
    exit(1)

try:
    with open('models/tokenizer_lstm.pkl', 'rb') as f:
        tokenizer_lstm = pickle.load(f)
except FileNotFoundError:
    print("Error: Tokenizer file 'tokenizer_lstm.pkl' not found.")
    exit(1)

try:
    with open('models/label_encoder.pkl', 'rb') as f:
        le = pickle.load(f)
except FileNotFoundError:
    print("Error: LabelEncoder file 'label_encoder.pkl' not found.")
    exit(1)

bert_tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
bert_model = TFBertModel.from_pretrained('bert-base-uncased')

def get_bert_embeddings(text, max_length=50):
    encodings = bert_tokenizer(
        [text], truncation=True, padding=True, max_length=max_length, return_tensors='tf'
    )
    outputs = bert_model(encodings['input_ids'], attention_mask=encodings['attention_mask'])
    return outputs.last_hidden_state[:, 0, :].numpy()

def preprocess_image(image_file, target_size=(64, 64)):
    img = load_img(image_file, target_size=target_size)
    img_array = img_to_array(img) / 255.0
    return img_array

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        name = request.form['name']
        username = request.form['username']
        bio = request.form['bio']
        followers = request.form['followers']
        posts = request.form['posts']
        profile_pic = request.files['profile_pic']

        # Validate numeric inputs
        try:
            followers = float(followers)
            posts = float(posts)
        except ValueError:
            return render_template('index.html', prediction='Error: Followers and posts must be numeric.')

        # Preprocess inputs
        name_length = len(name)
        username_length = len(username)
        name_username_similarity = fuzz.ratio(name.lower(), username.lower())
        numeric_features = np.array([[followers, posts, name_length, username_length, name_username_similarity]])

        # BERT embeddings for bio
        bio_emb = get_bert_embeddings(bio)

        # Text sequence for name + username
        text = name + ' ' + username
        seq = tokenizer_lstm.texts_to_sequences([text])
        text_seq = pad_sequences(seq, maxlen=20)

        # Image processing
        image_path = os.path.join('static', 'uploads', profile_pic.filename)
        os.makedirs(os.path.dirname(image_path), exist_ok=True)
        profile_pic.save(image_path)
        image_array = preprocess_image(image_path)

        # Predict with all models
        label_map = {0: 'Suspicious/Non-Clone', 1: 'Legitimate', 2: 'Clone'}
        
        # Neural Network prediction
        nn_pred = nn_model.predict([text_seq, bio_emb, numeric_features, np.expand_dims(image_array, axis=0)])
        nn_label = le.inverse_transform([np.argmax(nn_pred, axis=1)[0]])[0]
        nn_result = label_map[nn_label]
        
        # Combined features for SVM and RF
        text_seq_flat = text_seq.reshape(1, -1)
        image_flat = image_array.reshape(1, -1)
        combined_features = np.concatenate([text_seq_flat, bio_emb, numeric_features, image_flat], axis=1)
        
        # SVM prediction
        svm_pred = svm_model.predict(combined_features)
        svm_result = label_map[le.inverse_transform([svm_pred[0]])[0]]
        
        # Random Forest prediction
        rf_pred = rf_model.predict(combined_features)
        rf_result = label_map[le.inverse_transform([rf_pred[0]])[0]]

        return render_template('index.html', 
                             prediction=f'Neural Network: {nn_result}, SVM: {svm_result}, Random Forest: {rf_result}')
    except Exception as e:
        return render_template('index.html', prediction=f'Error: {str(e)}')

if __name__ == '__main__':
    app.run(debug=True)
import pandas as pd
import numpy as np
import os

# Create data directory
os.makedirs('data/images', exist_ok=True)

# Define sample data
names = [
    "John Doe", "Jane Smith", "Alex Johnson", "Emily Brown", "Michael Chen",
    "Sarah Davis", "Chris Wilson", "Laura Taylor", "David Lee", "Emma Clark"
]
usernames = [
    "john_doe123", "janesmith_456", "alex.johnson", "emilyb_789", "mikechen_",
    "sarahdavis99", "chris_wilson", "laura.taylor", "davidlee_22", "emmaclark_"
]
bios = [
    "Tech enthusiast | Blogger", "Lover of travel and coffee ☕", "Fitness freak 💪",
    "Just living life!", "Photographer | Nature lover", "Foodie | Recipe creator",
    "Dreamer | Artist", "Tech geek | Gamer", "Adventure seeker", "Book lover 📚"
]
labels = ["Suspicious/Non-Clone", "Legitimate", "Clone"]

# Generate synthetic data
np.random.seed(42)
n_samples = 100
data = {
    "name": [np.random.choice(names) for _ in range(n_samples)],
    "username": [],
    "bio": [np.random.choice(bios) for _ in range(n_samples)],
    "followers": np.random.randint(50, 10000, n_samples),
    "posts": np.random.randint(0, 500, n_samples),
    "profile_pic_path": [f"data/images/user{i+1}.jpg" for i in range(n_samples)],
    "label": [np.random.choice(labels) for _ in range(n_samples)]
}

# Generate usernames with variations
for i in range(n_samples):
    base_username = np.random.choice(usernames)
    if data["label"][i] == "Clone":
        # For clones, create similar usernames
        suffix = np.random.choice(["_fake", "_official", str(np.random.randint(1, 100))])
        data["username"].append(base_username + suffix)
    else:
        data["username"].append(base_username + str(np.random.randint(1, 1000)))

# Create DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv('data/instagram_accounts.csv', index=False)
print("Dataset saved to 'data/instagram_accounts.csv'.")

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
import seaborn as sns
import matplotlib.pyplot as plt
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Input, Concatenate, Dropout, LSTM
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from transformers import BertTokenizer, TFBertModel
from fuzzywuzzy import fuzz
import pickle
import tensorflow as tf
import nltk
import os

# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

# Create directories
os.makedirs('models', exist_ok=True)
os.makedirs('plots', exist_ok=True)

# Load dataset (assumes columns: name, username, bio, followers, posts, profile_pic_path, label)
data = pd.read_csv('data/instagram_accounts.csv')

# Handle missing values
data = data.dropna(subset=['name', 'username', 'bio', 'followers', 'posts', 'profile_pic_path', 'label'])

# Preprocess labels
le = LabelEncoder()
data['label'] = le.fit_transform(data['label'])  # e.g., Suspicious/Non-Clone -> 0, Legitimate -> 1, Clone -> 2

# Save LabelEncoder
with open('models/label_encoder.pkl', 'wb') as f:
    pickle.dump(le, f)

# Feature engineering: Numeric features
data['name_length'] = data['name'].str.len()
data['username_length'] = data['username'].str.len()
data['name_username_similarity'] = data.apply(
    lambda x: fuzz.ratio(str(x['name']).lower(), str(x['username']).lower()), axis=1
)
numeric_features = data[['followers', 'posts', 'name_length', 'username_length', 'name_username_similarity']].values

# BERT for bio
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
bert_model = TFBertModel.from_pretrained('bert-base-uncased')

def get_bert_embeddings(texts, max_length=50):
    encodings = tokenizer(
        texts.tolist(), truncation=True, padding=True, max_length=max_length, return_tensors='tf'
    )
    outputs = bert_model(encodings['input_ids'], attention_mask=encodings['attention_mask'])
    return outputs.last_hidden_state[:, 0, :].numpy()  # CLS token embeddings

bio_embeddings = get_bert_embeddings(data['bio'])

# Text preprocessing for LSTM (name + username)
texts = (data['name'] + ' ' + data['username']).values
tokenizer_lstm = Tokenizer(num_words=5000)
tokenizer_lstm.fit_on_texts(texts)
sequences = tokenizer_lstm.texts_to_sequences(texts)
max_seq_length = 20
text_sequences = pad_sequences(sequences, maxlen=max_seq_length)

# Save Tokenizer
with open('models/tokenizer_lstm.pkl', 'wb') as f:
    pickle.dump(tokenizer_lstm, f)

# Image preprocessing for CNN
def load_and_preprocess_image(image_path, target_size=(64, 64)):
    try:
        img = load_img(image_path, target_size=target_size)
        img_array = img_to_array(img) / 255.0  # Normalize to [0, 1]
        return img_array
    except Exception as e:
        print(f"Error loading image {image_path}: {e}")
        return np.zeros((target_size[0], target_size[1], 3))

image_features = np.array([load_and_preprocess_image(path) for path in data['profile_pic_path']])

# Split data
X_text_seq, X_text_seq_test, X_bio_emb, X_bio_emb_test, X_numeric, X_numeric_test, X_image, X_image_test, y, y_test = train_test_split(
    text_sequences, bio_embeddings, numeric_features, image_features, data['label'].values, test_size=0.2, random_state=42
)

# Neural Network Model
# Text sequence input (LSTM)
text_seq_input = Input(shape=(max_seq_length,))
x_text = tf.keras.layers.Embedding(5000, 128, input_length=max_seq_length)(text_seq_input)
x_text = LSTM(64, return_sequences=False)(x_text)
text_seq_features = Dense(64, activation='relu')(x_text)

# Bio BERT embeddings input
bio_emb_input = Input(shape=(768,))
bio_features = Dense(128, activation='relu')(bio_emb_input)

# Numeric input
numeric_input = Input(shape=(5,))
numeric_features_dense = Dense(32, activation='relu')(numeric_input)

# Image input (CNN)
image_input = Input(shape=(64, 64, 3))
x_img = Conv2D(32, (3, 3), activation='relu')(image_input)
x_img = MaxPooling2D((2, 2))(x_img)
x_img = Conv2D(64, (3, 3), activation='relu')(x_img)
x_img = MaxPooling2D((2, 2))(x_img)
x_img = Flatten()(x_img)
image_features_dense = Dense(128, activation='relu')(x_img)

# Combine features
combined = Concatenate()([text_seq_features, bio_features, numeric_features_dense, image_features_dense])
x = Dense(128, activation='relu')(combined)
x = Dropout(0.3)(x)
output = Dense(3, activation='softmax')(x)

# Build and compile Neural Network
nn_model = Model(inputs=[text_seq_input, bio_emb_input, numeric_input, image_input], outputs=output)
nn_model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train Neural Network
history = nn_model.fit(
    [X_text_seq, X_bio_emb, X_numeric, X_image], y,
    validation_data=([X_text_seq_test, X_bio_emb_test, X_numeric_test, X_image_test], y_test),
    epochs=15, batch_size=32
)

# Save Neural Network
nn_model.save('models/clone_detection_model.h5')

# Prepare combined features for SVM and Random Forest
combined_features = np.concatenate([X_text_seq.reshape(X_text_seq.shape[0], -1), X_bio_emb, X_numeric, X_image.reshape(X_image.shape[0], -1)], axis=1)
combined_features_test = np.concatenate([X_text_seq_test.reshape(X_text_seq_test.shape[0], -1), X_bio_emb_test, X_numeric_test, X_image_test.reshape(X_image_test.shape[0], -1)], axis=1)

# Train SVM
svm_model = SVC(kernel='rbf', probability=True)
svm_model.fit(combined_features, y)

# Save SVM
with open('models/svm_model.pkl', 'wb') as f:
    pickle.dump(svm_model, f)

# Train Random Forest
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(combined_features, y)

# Save Random Forest
with open('models/rf_model.pkl', 'wb') as f:
    pickle.dump(rf_model, f)

# Evaluate models
models = {
    'Neural Network': (nn_model, [X_text_seq_test, X_bio_emb_test, X_numeric_test, X_image_test]),
    'SVM': (svm_model, combined_features_test),
    'Random Forest': (rf_model, combined_features_test)
}

metrics = {'Model': [], 'Accuracy': [], 'Precision': [], 'Recall': [], 'F1-Score': []}

for model_name, (model, X_test) in models.items():
    if model_name == 'Neural Network':
        y_pred = model.predict(X_test)
        y_pred_classes = np.argmax(y_pred, axis=1)
    else:
        y_pred_classes = model.predict(X_test)
    
    report = classification_report(y_test, y_pred_classes, output_dict=True, zero_division=0)
    metrics['Model'].append(model_name)
    metrics['Accuracy'].append(report['accuracy'])
    metrics['Precision'].append(report['weighted avg']['precision'])
    metrics['Recall'].append(report['weighted avg']['recall'])
    metrics['F1-Score'].append(report['weighted avg']['f1-score'])
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred_classes)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=le.classes_, yticklabels=le.classes_)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title(f'Confusion Matrix - {model_name}')
    plt.savefig(f'plots/confusion_matrix_{model_name.lower().replace(" ", "_")}.png')
    plt.close()

# Plot metrics comparison
metrics_df = pd.DataFrame(metrics)
fig, ax = plt.subplots(figsize=(10, 6))
metrics_df.set_index('Model')[['Accuracy', 'Precision', 'Recall', 'F1-Score']].plot(kind='bar', ax=ax)
plt.title('Model Performance Comparison')
plt.ylabel('Score')
plt.xticks(rotation=45)
plt.legend(loc='lower right')
plt.tight_layout()
plt.savefig('plots/metrics_comparison.png')
plt.close()

print("Training complete. Models saved in 'models/'. Plots saved in 'plots/'.")